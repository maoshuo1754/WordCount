#!/bin/bash
start_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
export PYTHONIOENCODING=utf-8

ls -lh /myspace

# data processing
python tools/gen_det_ann_fs.py

ls -lh /myspace/test_dataset_fs
ls -lh /myspace/test_dataset_fs/annotations

mkdir /myspace/mmdet/result
ls -lh /myspace/mmdet/result

ls -lh /myspace/checkpoints/

finish_time1=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time1")-$(date +%s -d "$start_time")))))
echo "****************this shell script execution duration: $duration"

python mmdetection/tools/test.py config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_i.py /myspace/mmdet/image/images_cascade.pth \
	--format_only --options "jsonfile_prefix=/myspace/mmdet/result/i_fs_cascade"

python tools/json_taobao_2_submit.py \
	--input /myspace/mmdet/result/i_fs_cascade.bbox.json \
	--ann /myspace/test_dataset_fs/annotations/test_image.json \
	--output /myspace/mmdet/result/i_fs_cascade.json

python mmdetection/tools/test.py config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_v.py /myspace/mmdet/image/videos_cascade.pth \
	--format_only --options "jsonfile_prefix=/myspace/mmdet/result/v_fs_cascade"

python tools/json_taobao_2_submit.py \
	--input /myspace/mmdet/result/v_fs_cascade.bbox.json \
	--ann /myspace/test_dataset_fs/annotations/test_video.json \
	--output /myspace/mmdet/result/v_fs_cascade.json

python tools/filter_ann.py

finish_time2=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time2")-$(date +%s -d "$finish_time1")))))
echo "****************this shell script execution duration: $duration"

mkdir /myspace/feat

# rs101_alll_circle_386_198_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

# rs101_alll_circle_256_256_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

# rx101_alll_circle_256_256_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

# rx101_alll_circle_386_198_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnext101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/rx101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

# se101_alll_circle_256_256_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_256_256_19_lr.pth \
	--output /myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr.pkl \
	--input_size_h 256 \
	--input_size_w 256 \
	--flip 0

# se101_alll_circle_386_198_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name se_resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/se101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

# r101_alll_circle_386_198_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/r101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/r101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/r101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnet101_ibn_a \
	--gem_pool on \
	--checkpoint_path /checkpoints/r101_alll_circle_386_198_lr.pth \
	--output /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

# cp -r result/feat.pkl /myspace/result/feat_resnet50_1v2i_nopad_more_epoch_ep119.pkl
ls -lh /myspace/feat

finish_time3=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time3")-$(date +%s -d "$finish_time2")))))
echo "****************this shell script execution duration: $duration"

python tools/search_f1_merge_dist_frame.py \
	--feat_path1 /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr.pkl /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr.pkl /myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr.pkl /myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr.pkl /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--feat_path2 /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr.pkl /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr.pkl /myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr.pkl /myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr.pkl /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--steps 3 2 2 2 2 \
	--output result.json


finish_time4=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time4")-$(date +%s -d "$finish_time3")))))
echo "****************this shell script execution duration: $duration"



finish_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time")-$(date +%s -d "$start_time")))))
echo "****************this shell script execution duration: $duration"
