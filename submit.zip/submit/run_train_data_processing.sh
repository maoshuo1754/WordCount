start_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`

export PYTHONIOENCODING=utf-8

ls -l /home/admin/workspace/myspace

mkdir /home/admin/workspace/myspace/mmdet

python tools/process_data_train.py --dataset train_dataset_part1  --id 0

# python tools/process_data_train.py --dataset train_dataset_part2  --id 1
# python tools/process_data_train.py --dataset train_dataset_part3  --id 2
# python tools/process_data_train.py --dataset train_dataset_part4  --id 3
# python tools/process_data_train.py --dataset train_dataset_part5  --id 4
# python tools/process_data_train.py --dataset train_dataset_part6  --id 5
# python tools/process_data_train.py --dataset validation_dataset_part1  --id 6
# python tools/process_data_train.py --dataset validation_dataset_part2  --id 7

finish_time1=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time1")-$(date +%s -d "$start_time")))))
echo "****************this shell script execution duration: $duration"

finish_time2=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time2")-$(date +%s -d "$finish_time1")))))
echo "****************this shell script execution duration: $duration"

ls -lh /home/admin/workspace/myspace/train

python tools/merge_dataset.py
python tools/change_num_classes.py

ls -lh /home/admin/workspace/myspace/mmdet/image

finish_time3=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time3")-$(date +%s -d "$finish_time2")))))
echo "****************this shell script execution duration: $duration"

finish_time4=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time4")-$(date +%s -d "$finish_time3")))))
echo "****************this shell script execution duration: $duration"

