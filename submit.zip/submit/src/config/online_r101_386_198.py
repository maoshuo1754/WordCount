class Config:
    # common
    mode = 'train'
    snap = 'r101_386_198'  # 实验名称
    log_dir = '/home/admin/workspace/myspace/work_dirs/retrieval'  # log 存放的目录
 
    # data
    pos = 'tianchi'
    input_size = (386, 198)
    root = ''  # 图像所在目录
    ann_path = ''  # 标注文件，用于读取bbox和instance_id
    dataset = 'online'  # online 默认使用天池官方机器训练，不需要指定 root 和 ann_path，已经写死在 dataset 内
    batch_size = 1 * 4 * 3
    num_instances = 3
    pair = (1, 2) # 采样 1 张 video 图，2张 images 图
    num_classes = 5000 # 这个值会根据dataset自动改变

    # model
    model_name = 'resnet101_ibn_a'
    pretrain_path = '/home/admin/workspace/myspace/pretrain/resnet101_ibn_a.pth.tar'  # 预训练模型
    gem_pool = 'on'  # 默认是 p=3
    optimizer_name = 'adam'
    pair_loss_type = 'trip'
    id_loss_type = 'circle'
    base_lr = 7e-4
    weight_decay = 0.0005
        # loss
    ce_weight = 1.0
    triplet_weight = 1.0
    margin = 0.3
    label_smooth = False
    COSINE_SCALE = 256
    COSINE_MARGIN = 0.25

    # train
    num_epochs = 100
    SAVED_PIRIOD = 10
    VAL_PIRIOD = 100
        # lr
    lr_scheduler = 'lr'
    milestones = [35, 70]
    gamma = 0.1
    warmup_iters = 10

    checkpoint_path = ''

    # val: 不生成 pkl 文件，只出验证结果
        # pos = tianchi: 使用 faster rcnn 真实检测结果 进行验证。
        # pos = local: 使用 gt 检测结果进行验证。一般使用这个
    val_batch_size = 512
    val_root = ''
    val_ann_path = ''

    # test: 生成 pkl 文件
        # pos = tianchi: 使用 faster rcnn 真实检测结果，生成的 feat.pkl 中 bbox 不包含 instance_id 字段。线上跑用这个
        # pos = local: 使用 gt 检测结果，生成的 feat.pkl 中 bbox 包含 instance_id 字段, bbox[-1] = instance_id
    test_batch_size = 512
    test_root = ''
    test_ann_path = ''
    output = ''  # 输出文件的名称，默认存放在 log 目录下

