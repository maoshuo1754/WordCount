from torch import nn
import torch
from .resnet import ResNet, BasicBlock, Bottleneck, weights_init_kaiming, weights_init_classifier
from .resnet_ibn_a import resnet50_ibn_a, resnet101_ibn_a, resnet152_ibn_a, se_resnet101_ibn_a, se_resnet50_ibn_a
from .resnext_ibn_a import resnext50_ibn_a, resnext101_ibn_a
from .resnet_nl import ResNetNL
from .resnest import resnest50, resnest101
from .arcloss import MagrginLinear
from .gem_pooling import GeneralizedMeanPoolingP
from .metric_learning import Arcface, Cosface, AMSoftmax, CircleLoss

class Baseline(nn.Module):
    in_planes = 2048

    def __init__(self, num_classes, last_stride, model_path, model_name, neck_feat='after', pretrain_choice='imagenet', gem_pool='on', cfg=None):
        super(Baseline, self).__init__()
        if model_name == 'resnet18':
            self.in_planes = 512
            self.base = ResNet(last_stride=last_stride, 
                               block=BasicBlock, 
                               layers=[2, 2, 2, 2])
        elif model_name == 'resnet34':
            self.in_planes = 512
            self.base = ResNet(last_stride=last_stride,
                               block=BasicBlock,
                               layers=[3, 4, 6, 3])
        elif model_name == 'resnet50':
            self.base = ResNet(last_stride=last_stride,
                               block=Bottleneck,
                               layers=[3, 4, 6, 3])
        elif model_name == 'resnet50_nl':
            self.base = ResNetNL(last_stride=last_stride,
                               block=Bottleneck,
                               layers=[3, 4, 6, 3],
                               non_layers=[0, 2, 3, 0])
        elif model_name == 'resnet101':
            self.base = ResNet(last_stride=last_stride,
                               block=Bottleneck, 
                               layers=[3, 4, 23, 3])
        elif model_name == 'resnet152':
            self.base = ResNet(last_stride=last_stride, 
                               block=Bottleneck,
                               layers=[3, 8, 36, 3])
        elif model_name == 'resnet50_ibn_a':
            self.base = resnet50_ibn_a(last_stride)
        elif model_name == 'resnet101_ibn_a':
            self.base = resnet101_ibn_a(last_stride)
        elif model_name == 'se_resnet101_ibn_a':
            self.base = se_resnet101_ibn_a(last_stride)
        elif model_name == 'se_resnet50_ibn_a':
            self.base = se_resnet50_ibn_a(last_stride)
        elif model_name == 'resnext101_ibn_a':
            self.base = resnext101_ibn_a(last_stride)
        elif model_name == 'resnext50_ibn_a':
            self.base = resnext50_ibn_a(last_stride)
        elif model_name == 'resnest50':
            self.base = resnest50(last_stride)
        elif model_name == 'resnest101':
            self.base = resnest101(last_stride)
        # self.reduction = nn.Sequential(
        #     nn.Conv2d(2048, 512, kernel_size=1, bias=False),
        #     nn.BatchNorm2d(512),
        #     nn.ReLU()
        # )
        # self.in_planes = 512
        # self.reduction.apply(weights_init_kaiming)

        self.neck_feat = neck_feat
        if gem_pool == 'on':
            print("Generalized Mean Pooling")
            self.gap = GeneralizedMeanPoolingP()
        else:
            self.gap = nn.AdaptiveAvgPool2d(1)
        # self.gap = nn.AdaptiveMaxPool2d(1)
        self.num_classes = num_classes
        self.bottleneck = nn.BatchNorm1d(self.in_planes)
        self.bottleneck.bias.requires_grad_(False)  # no shift
        self.bottleneck.apply(weights_init_kaiming)
        
        self.ID_LOSS_TYPE = 'CE' if cfg.mode == 'test' else cfg.id_loss_type
        if self.ID_LOSS_TYPE == 'arcface':
            print('using {}'.format(self.ID_LOSS_TYPE))
            self.classifier = Arcface(self.in_planes, self.num_classes,
                                      s=cfg.COSINE_SCALE, m=cfg.COSINE_MARGIN)
        elif self.ID_LOSS_TYPE == 'cosface':
            print('using {}'.format(self.ID_LOSS_TYPE))
            self.classifier = Cosface(self.in_planes, self.num_classes,
                                      s=cfg.COSINE_SCALE, m=cfg.COSINE_MARGIN)
        elif self.ID_LOSS_TYPE == 'amsoftmax':
            print('using {}'.format(self.ID_LOSS_TYPE))
            self.classifier = AMSoftmax(self.in_planes, self.num_classes,
                                      s=cfg.COSINE_SCALE, m=cfg.COSINE_MARGIN)
        elif self.ID_LOSS_TYPE == 'circle':
            print('using {}'.format(self.ID_LOSS_TYPE))
            self.classifier = CircleLoss(self.in_planes, self.num_classes,
                                        s=cfg.COSINE_SCALE, m=cfg.COSINE_MARGIN)
        else:
            print('using {}'.format(self.ID_LOSS_TYPE))
            self.classifier = nn.Linear(self.in_planes, self.num_classes, bias=False)
        self.classifier.apply(weights_init_classifier)

        self.attr_classifier = nn.Linear(self.in_planes, 23, bias=False)
        self.attr_classifier.apply(weights_init_classifier)
        if pretrain_choice == 'imagenet':
            self.base.load_param(model_path)
            print('Loading pretrained ImageNet model......')
        elif pretrain_choice == 'self':
            self.load_param(model_path)
            print('Loading pretrained self model......')

    def forward(self, x, label=None):
        x = self.base(x)
        # x = self.reduction(x)

        global_feat = self.gap(x)  # (b, 2048, 1, 1)
        global_feat = global_feat.view(global_feat.shape[0], -1)  # flatten to (bs, 2048)

        feat = self.bottleneck(global_feat)  # normalize for angular softmax
        attr_score = self.attr_classifier(global_feat)

        if self.training:
            if self.ID_LOSS_TYPE in ('arcface', 'cosface', 'amsoftmax', 'circle'):
                cls_score = self.classifier(feat, label)
            else:
                cls_score = self.classifier(feat)
            return cls_score, attr_score, feat
        else:
            if self.neck_feat == 'after':
                # print("Test with feature after BN")
                # return torch.cat([feat, attr_score], dim=1)
                return feat
            else:
                # print("Test with feature before BN")
                # return torch.cat([global_feat, attr_score], dim=1)
                return global_feat

    def load_param(self, trained_path):
        param_dict = torch.load(trained_path)['state_dict']
        for i in param_dict:
            if self.state_dict()[i].shape != param_dict[i].shape:
                print('skip {}, shape dismatch {} vs {}'.format(i, self.state_dict()[i].shape, param_dict[i].shape))
                continue
            self.state_dict()[i].copy_(param_dict[i])
