from .base import Baseline
import torch
from .lr_scheduler import WarmupMultiStepLR, GradualWarmupScheduler, WarmupCosineLR
import torch.optim as optim
from .ranger import Ranger
from .lookahead import Lookahead
from .radam import RAdam

def build_model(cfg):
    if cfg.mode == 'train':
        model = Baseline(cfg.num_classes, last_stride=1, 
            model_path=cfg.pretrain_path, model_name=cfg.model_name, pretrain_choice='imagenet', gem_pool=cfg.gem_pool, cfg=cfg)
    elif cfg.mode == 'val' or cfg.mode == 'test':
        model = Baseline(cfg.num_classes, last_stride=1, 
            model_path=cfg.pretrain_path, model_name=cfg.model_name, pretrain_choice=None, gem_pool=cfg.gem_pool, cfg=cfg)
        model.load_param(cfg.checkpoint_path)
        print('load from: ', cfg.checkpoint_path)
    return model

def build_optimizer(cfg, model):
    params_to_update = model.parameters()

    if cfg.optimizer_name == 'lookahead':
        # optimizer = optim.Adam(params_to_update, lr=cfg.base_lr, weight_decay=cfg.weight_decay)
        optimizer = RAdam(params_to_update, lr=cfg.base_lr, weight_decay=cfg.weight_decay)
        print('using lookahead!')
        optimizer = Lookahead(optimizer)
    elif cfg.optimizer_name == 'ranger':
        print('using ranger!')
        optimizer = Ranger(params_to_update, lr=cfg.base_lr, weight_decay=cfg.weight_decay)
    else:
        optimizer = optim.Adam(params_to_update, lr=cfg.base_lr, weight_decay=cfg.weight_decay)

    return optimizer

def build_lr_scheduler(cfg, optimizer):
    if cfg.lr_scheduler == 'lr':
        scheduler = WarmupMultiStepLR(optimizer, milestones=cfg.milestones, gamma=cfg.gamma,warmup_factor=0.01, 
            warmup_iters=cfg.warmup_iters, warmup_method="linear", last_epoch=-1)
    elif cfg.lr_scheduler == 'cos':
        # cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, cfg.num_epochs, eta_min=7e-7, last_epoch=-1)
        # scheduler = GradualWarmupScheduler(optimizer, multiplier=cfg.warmup_iters, total_epoch=cfg.warmup_iters-1, after_scheduler=cosine_scheduler)
        scheduler = WarmupCosineLR(optimizer, max_epochs=cfg.num_epochs, warmup_epochs=cfg.warmup_iters, eta_min=7e-7, last_epoch=-1,)
    return scheduler
