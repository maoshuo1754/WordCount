import math
import time
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm
import pickle
import pdb
import argparse
from data.build import build_dataloader, build_dataset, build_val_dataloader
from loss.build import build_loss
from model.build import build_lr_scheduler, build_model, build_optimizer
from util.logger import setup_logger
from util.metrics import metric


def parse_args():
    parser = argparse.ArgumentParser(
        description='ReID Baseline Training')
    parser.add_argument('--mode', type=str)
    parser.add_argument('--cfg_name', type=str)
    parser.add_argument('--pos', default='local', type=str)
    parser.add_argument('--gpus', default='0', type=str)
    args = parser.parse_args()
    return args

def config_info(cfg, logger):
    for key, value in cfg.__dict__.items():
        if key.startswith('_'):
            continue
        logger.info(f'{key}: {value}')
    # print(vars(cfg))

def run_val(model, dataloader):
    model.eval()
    feats = []
    paths = []
    bboxes = []
    for i, input in tqdm(enumerate(dataloader), total=len(dataloader)):
        img = input['image']
        img = img.cuda()
        with torch.no_grad():
            feature = model(img)
        feature = feature.cpu().numpy()
        paths += input['path']
        feats.append(feature)
        bboxes.append(input['bbox'].numpy())
    
    bboxes = np.vstack(bboxes)
    feats = np.vstack(feats)

    res_focus = metric(paths, feats, bboxes, val=True)
    res_all = metric(paths, feats, bboxes, val=False)
    return res_focus, res_all

def do_train(cfg):
    logger = setup_logger(cfg.snap, cfg.log_dir, 0)
    config_info(cfg, logger)

    dataset = build_dataset(cfg)
    cfg.num_classes = dataset.num_classes
    dataloader = build_dataloader(cfg, dataset)
    val_dataloader = build_val_dataloader(cfg)
    model = build_model(cfg)
    model = model.cuda()
    model = nn.DataParallel(model)
    
    criterion = build_loss(cfg)
    optimizer = build_optimizer(cfg, model)
    scheduler = build_lr_scheduler(cfg, optimizer)
    
    since = time.time()

    for epoch in range(cfg.num_epochs):
        logger.info('Epoch {}/{}'.format(epoch, cfg.num_epochs - 1))

        # Each epoch has a training and validation phase
        model.train()  # Set model to training mode
        running_loss = 0.0
        running_loss_all = np.zeros(shape=(3))
        running_corrects = 0
        # Iterate over data.
        for name, inputs, labels, cates in tqdm(dataloader):
            optimizer.zero_grad()
            inputs = inputs.cuda()
            labels = labels.cuda()
            cates = cates.cuda()

            logit, attr_logit, global_feat = model(inputs, labels)
            loss, record_loss = criterion(logit, global_feat, labels)
            _, preds = torch.max(logit, 1)

            loss.backward()
            optimizer.step()
            # statistics
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

            for i, l in enumerate(record_loss):
                running_loss_all[i] += l.item() * inputs.size(0)

        epoch_loss = running_loss / len(dataloader.sampler)
        epoch_loss_all = running_loss_all / len(dataloader.sampler)
        epoch_acc = running_corrects.double() / len(dataloader.sampler)
        logger.info('train lr: {:.7f} Loss: {:.6f} Acc: {:.6f} cls Loss: {:.6f} triplet loss: {:.6f}'.format(
            scheduler.get_lr()[0], epoch_loss, epoch_acc, epoch_loss_all[0], epoch_loss_all[1]))

        if (epoch + 1) % cfg.SAVED_PIRIOD == 0:
            torch.save({
                'epoch': epoch,
                'state_dict': model.module.state_dict(),
            },
            os.path.join(cfg.log_dir, cfg.snap,'ckpt_ep{}.pth'.format(epoch)))

        if (epoch + 1) % cfg.VAL_PIRIOD == 0:
            res_focus, res_all = run_val(model, val_dataloader)
            logger.info('val select top5, focus acc: {:.6f}, all acc: {:.6f}'.format(res_focus, res_all))

        if scheduler is not None:  # after val at this epoch
            scheduler.step()

        logger.info('\n')
    time_elapsed = time.time() - since
    logger.info('{} - Training complete in {:.0f}m {:.0f}s'.format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        time_elapsed // 60, time_elapsed % 60))



def do_train_online(cfg):
    logger = setup_logger(cfg.snap, cfg.log_dir, 0)
    config_info(cfg, logger)

    dataset = build_dataset(cfg)
    cfg.num_classes = dataset.num_classes
    dataloader = build_dataloader(cfg, dataset)
    model = build_model(cfg)
    model = model.cuda()
    model = nn.DataParallel(model)
    
    criterion = build_loss(cfg)
    optimizer = build_optimizer(cfg, model)
    scheduler = build_lr_scheduler(cfg, optimizer)
    
    since = time.time()

    for epoch in range(cfg.num_epochs):
        logger.info('Epoch {}/{}'.format(epoch, cfg.num_epochs - 1))

        # Each epoch has a training and validation phase
        model.train()  # Set model to training mode
        running_loss = 0.0
        running_loss_all = np.zeros(shape=(3))
        running_corrects = 0
        all_preds = torch.empty([0]).int()
        all_labels = torch.empty([0]).int()
        # Iterate over data.
        for name, inputs, labels in tqdm(dataloader):
            optimizer.zero_grad()
            inputs = inputs.cuda()
            labels = labels.cuda()

            logit, global_feat = model(inputs, labels)
            loss, record_loss = criterion(logit, global_feat, labels)

            _, preds = torch.max(logit, 1)

            loss.backward()
            optimizer.step()

            all_preds = torch.cat([all_preds, preds.cpu().int()], 0)
            all_labels = torch.cat([all_labels, labels.data.cpu().int()], 0)
            # statistics
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

            for i, l in enumerate(record_loss):
                running_loss_all[i] += l.item() * inputs.size(0)

        epoch_loss = running_loss / len(dataloader.sampler)
        epoch_loss_all = running_loss_all / len(dataloader.sampler)
        epoch_acc = running_corrects.double() / len(dataloader.sampler)
        all_labels = all_labels.numpy()
        all_preds = all_preds.numpy()
        logger.info('train lr: {:.7f} cls Loss: {:.6f} Acc: {:.6f} cls Loss: {:.6f} triplet loss: {:.6f}'.format(
            scheduler.get_lr()[0], epoch_loss, epoch_acc, epoch_loss_all[0], epoch_loss_all[1]))

        if (epoch + 1) % cfg.SAVED_PIRIOD == 0:
            torch.save({
                'epoch': epoch,
                'state_dict': model.module.state_dict(),
            },
            os.path.join(cfg.log_dir, cfg.snap,'ckpt_ep{}.pth'.format(epoch)))

        if scheduler is not None:  # after val at this epoch
            scheduler.step()

        logger.info('\n')
    time_elapsed = time.time() - since
    logger.info('{} - Training complete in {:.0f}m {:.0f}s'.format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        time_elapsed // 60, time_elapsed % 60))


def do_val(cfg):
    dataloader = build_val_dataloader(cfg)
    model = build_model(cfg)
    model = model.cuda()
    if torch.cuda.device_count() > 0:
        model = nn.DataParallel(model)
    
    res_focus, res_all = run_val(model, dataloader)
    print('val select top2, focus acc: {:.6f}, all acc: {:.6f}'.format(res_focus, res_all))


def infrence(cfg):
    dataset = build_dataset(cfg)
    dataloader = build_dataloader(cfg, dataset)

    model = build_model(cfg)
    model = model.cuda()
    if torch.cuda.device_count() > 0:
        model = nn.DataParallel(model)
    
    model.eval()
    feats = []
    paths = []
    bboxes = []
    for i, input in tqdm(enumerate(dataloader), total=len(dataloader)):
        img = input['image']
        img = img.cuda()
        with torch.no_grad():
            feature = model(img)
        feature = feature.cpu().numpy()
        paths += input['path']
        feats.append(feature)
        bboxes.append(input['bbox'].numpy())
    
    bboxes = np.vstack(bboxes)
    feats = np.vstack(feats)
    # output = os.path.join(cfg.log_dir, cfg.output)
    with open(cfg.output, 'wb') as f:
        pickle.dump(
            {
                'images': paths,
                'bbox':bboxes,
                'feat': feats,
            },
            f
        )

def main(cfg):
    if cfg.mode == 'train':
        if cfg.dataset == 'online':
            do_train_online(cfg)
        else:
            do_train(cfg)
    elif cfg.mode == 'val':
        do_val(cfg)
    elif cfg.mode == 'test':
        infrence(cfg)

if __name__ == "__main__":
    args = parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
    exec('from config.{} import Config as cfg'.format(args.cfg_name))
    torch.backends.cudnn.benchmark = True
    cfg.mode = args.mode
    main(cfg)
