import numpy as np
from tqdm import tqdm
import pdb
import faiss
from collections import Counter
from sklearn.preprocessing import normalize
from tqdm import tqdm
import argparse

def metric(names, feat, bbox, val=False):
    '''
    val = True 仅测试 video 图中 instance_id != 0 的图像
    '''
    v_index_2_name = []
    v_feat = []
    v_bbox = []
    i_index_2_name = []
    i_feat = []
    i_bbox = []
    v_i = 0
    i_i = 0

    names = np.array(names)

    v_index = []
    i_index = []

    for i in range(len(names)):
        if names[i].startswith('v_'):
            v_index.append(i)
        else:
            i_index.append(i)
    v_feat = feat[v_index]
    i_feat = feat[i_index]
    v_bbox = bbox[v_index]
    i_bbox = bbox[i_index]
    v_index_2_name = names[v_index]
    i_index_2_name = names[i_index]

    if val:
        idx = v_bbox[:, -1] != 0
        v_bbox = v_bbox[idx]
        v_index_2_name = v_index_2_name[idx]
        v_feat = v_feat[idx]

    v_feat = normalize(v_feat, axis=1)
    i_feat = normalize(i_feat, axis=1)

    index = faiss.IndexFlatIP(v_feat.shape[1])   # build the index
    index.add(i_feat)                  # add vectors to the index

    k = 2                          # we want to see 4 nearest neighbors
    D, I = index.search(v_feat, k) # sanity check

    TOP = k
    # top1_idx = I[:, :TOP]
    # top1_name = i_index_2_name[top1_idx]
    # res_dict = {}
    # acc_v_idx = []
    # all_v_num = []
    # for i in tqdm(range(len(v_feat))):
    #     v_name = v_index_2_name[i].split('_')[1]
    #     if v_name not in res_dict:
    #         res_dict[v_name] = Counter()
    #     i_names = []
    #     for m, name in enumerate(top1_name[i]):
    #         i_names.extend([name.split('_')[2][:-4] for _ in range(TOP - m)])
    #     res_dict[v_name].update(i_names)
    #     if v_name not in all_v_num:
    #         all_v_num.append(v_name)
    #     if v_name in i_names:
    #         acc_v_idx.append(i)
    # # print('acc ann number: {}, all ann num {}, acc video ann: {}'.format(
    # #     len(acc_v_idx), len(v_index_2_name), len(acc_v_idx) / len(v_index_2_name)))

    # v_top = 1
    # acc_v = []
    # error_v = []
    # for v_name, counter in res_dict.items():
    #     most_common = counter.most_common(v_top)
    #     i_name = [x[0] for x in most_common]
    #     if v_name in i_name:
    #         acc_v.append(v_name)
    #     else:
    #         error_v.append(v_name)
    # # print('V_TOP: {}, acc video num: {}, video num: {}, acc: {}'.format(
    # #     v_top, len(acc_v), len(res_dict), len(acc_v) / len(res_dict)))
    # return len(acc_v) / len(res_dict)

    top1_idx = I[:, :TOP]
    top1_dis = D[:, :TOP]
    top1_name = i_index_2_name[top1_idx]

    res_dict = {}
    acc_v_idx = []
    all_v_num = []
    for i in range(len(v_feat)):
        v_name = v_index_2_name[i].split('_')[1]
        if v_name not in res_dict:
            res_dict[v_name] = {}
        i_names = []
        for m, name in enumerate(top1_name[i]):
            name = name.split('_')[2][:-4]
            if name not in res_dict[v_name]:
                res_dict[v_name][name] = 0
            res_dict[v_name][name] += top1_dis[i, m]
            i_names.append(name)
        if v_name not in all_v_num:
            all_v_num.append(v_name)
        if v_name in i_names:
            acc_v_idx.append(i)
    v_top = 1
    acc_v = []
    for v_name, counter in res_dict.items():
        most_common = sorted(counter.items(), key=lambda d:d[1])[-v_top:]
        i_name = [x[0] for x in most_common]
        if v_name in i_name:
            acc_v.append(v_name)
    return len(acc_v) / len(res_dict)

