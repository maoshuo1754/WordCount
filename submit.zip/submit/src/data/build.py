from .dataset import BoxDataset, BoxTestDataset, BoxValDataset, BoxAllDataset, BoxOnlineDataset
from torchvision import transforms
from .autoaugment import ImageNetPolicy, CIFAR10Policy
from .randaugment import RandAugment
from .triplet_sample import RandomIdentitySampler, RandomIdentitySamplerCls
from .transform import Padding
import torch
# import albumentations as A
# from albumentations.pytorch import ToTensor

def build_transform(cfg):
    if not isinstance(cfg.input_size, (tuple, list)):
        cfg.input_size = (cfg.input_size, cfg.input_size)
    if cfg.mode == 'train':
        transform = transforms.Compose([
            transforms.Resize(cfg.input_size),
            # ImageNetPolicy(fillcolor=(255,255,255)),
            CIFAR10Policy(fillcolor=(255,255,255)),
            # RandAugment(2, 9),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
            # transforms.RandomErasing(),
        ])
    elif cfg.mode == 'val' or cfg.mode == 'test':
        transform = transforms.Compose([
            transforms.Resize(cfg.input_size),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])
    return transform

def build_dataset(cfg):
    transform = build_transform(cfg)
    if cfg.mode == 'train':
        if cfg.dataset == 'all':
            return BoxAllDataset(cfg.root, (1,2,3,4,5,6), transform, num_classes=cfg.num_classes)
        elif cfg.dataset == '1':
            return BoxDataset(cfg.root, cfg.ann_path, transform, num_classes=cfg.num_classes)
        elif cfg.dataset == 'online':
            return BoxOnlineDataset(cfg.root, transform, num_classes=cfg.num_classes)
    elif cfg.mode == 'val':
        if cfg.pos == 'tianchi':
            return BoxTestDataset(cfg.val_root, cfg.val_ann_path, transform)
        elif cfg.pos == 'local':
            return BoxValDataset(cfg.val_root, cfg.val_ann_path, transform)
        else:
            raise('cfg.pos is invalid')
    elif cfg.mode == 'test':
        if cfg.pos == 'tianchi':
            return BoxTestDataset(cfg.test_root, cfg.test_ann_path, transform)
        elif cfg.pos == 'local':
            return BoxValDataset(cfg.test_root, cfg.test_ann_path, transform)
        else:
            raise('cfg.pos is invalid')

def build_dataloader(cfg, dataset):
    if cfg.mode == 'train':
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.batch_size,
            sampler=RandomIdentitySampler(dataset.targets, dataset.domain, cfg.batch_size, cfg.num_instances, cfg.pair), 
            num_workers=0)
        # dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.batch_size,
        #     sampler=RandomIdentitySamplerCls(dataset.targets, dataset.domain, dataset.labels, cfg.batch_size, cfg.num_instances, cfg.pair), 
        #     num_workers=0)
    elif cfg.mode == 'val':
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.val_batch_size, shuffle=False, num_workers=0)
    elif cfg.mode == 'test':
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.test_batch_size, shuffle=False, num_workers=0)
    return dataloader

def build_test_dataloader(cfg):
    if cfg.flip == 1:
        print('flip open')
        transform = transforms.Compose([
                transforms.Resize((cfg.input_size_h, cfg.input_size_w)),
                transforms.RandomHorizontalFlip(p=1.0),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
            ])
    else:
        transform = transforms.Compose([
                transforms.Resize((cfg.input_size_h, cfg.input_size_w)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
            ])
    if cfg.pos == 'tianchi':
        dataset = BoxTestDataset(cfg.root, cfg.ann_path, transform)
    elif cfg.pos == 'local':
        dataset = BoxValDataset(cfg.root, cfg.ann_path, transform)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.batch_size, shuffle=False, num_workers=0)
    return dataloader

def build_val_dataloader(cfg):
    data_dir = cfg.val_root
    ann_json = cfg.val_ann_path
    transform = transforms.Compose([
            transforms.Resize(cfg.input_size),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
    dataset = BoxValDataset(data_dir, ann_json, transform)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=cfg.val_batch_size, shuffle=False, num_workers=0)
    return dataloader
