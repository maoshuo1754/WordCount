import os
from PIL import Image
import pandas as pd
import numpy as np
import json
import cv2
import random
import pdb

def pil_loader(path):
    # open path as file to avoid ResourceWarning (https://github.com/python-pillow/Pillow/issues/835)
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')

def cv2_loader(path):
    image = cv2.imread(path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image

def crop_img(img, bbox, mode='val'):
    width, height = img.size
    # if mode == 'train':
    #     ratio = 0.1 + ((random.random() - 0.5) * 0.02)  # [0.09, 0.11]
    # else:
    #     ratio = 0.1
    ratio = 0
    x1,y1,x2,y2 = bbox
    x_margin = int((x2 - x1) * ratio)
    y_margin = int((y2 - y1) * ratio)
    x1 = max(0, x1 - x_margin)
    y1 = max(0, y1 - y_margin)

    x2 = min(x2 + x_margin, width)
    y2 = min(y2 + y_margin, height)
    img = img.crop((x1, y1, x2, y2))
    return img


class BoxDataset(object):
    def __init__(self, root, ann_path, transforms, num_classes=10):
        self.root = root
        with open(ann_path, 'r') as f:
            self.ann = json.load(f)
        self.transform = transforms
        self.num_classes = num_classes

        self.images, self.bboxes, self.targets, self.cls_to_id, self.domain, self.labels = self.filter_images(self.ann)

        print('images number: {}, num classes: {}'.format(len(self.images), self.num_classes))

    def get_all_in(self, df):
        ins = df['instance_id'].unique()
        ok_num = 0
        ok_ins = []
        for id in ins:
            if id == 0:
                continue
            if len(df[df['instance_id'] == id]['type'].unique()) > 1:
                ok_num += 1
                ok_ins.append(id)
        print(f'all in: {ok_num}, all ins: {len(ins)}, ratio: {ok_num/len(ins)}')
        return ok_ins

    def filter_images(self, ann):
        ann_df = pd.DataFrame(ann['annotations'])
        img_df = pd.DataFrame(ann['images'])
        merge_df = ann_df.merge(img_df, how='left', left_on='image_id', right_on='id')
        merge_df['type'] = merge_df['file_name'].apply(lambda x: x[0])
        # merge_df = merge_df[merge_df.type == 'i']
        instance_ids = self.get_all_in(merge_df)
        inds = merge_df.instance_id.isin(instance_ids)
        images = merge_df.loc[inds, 'file_name'].tolist()
        bboxes = merge_df.loc[inds, 'bbox'].tolist()
        bboxes = [[x, y, x + w, y + h] for x, y, w, h in bboxes]
        targets = merge_df.loc[inds, 'instance_id'].tolist()
        domain = merge_df.loc[inds, 'type'].tolist()
        labels = merge_df.loc[inds, 'category_id'].tolist()
        labels_name = merge_df.loc[inds, 'category_id'].unique()
        cls_to_id = {instance: id for id, instance in enumerate(instance_ids)}
        cls_to_id_labels = {label: id for id, label in enumerate(labels_name)}

        targets = [cls_to_id[cls] for cls in targets]
        labels = [cls_to_id_labels[cls] for cls in labels]

        images = [os.path.join(self.root, name) for name in images]

        self.num_classes = len(instance_ids)
        return images, bboxes, targets, cls_to_id, domain, labels

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path = self.images[index]
        bbox = self.bboxes[index]
        target = self.targets[index]
        domain = self.domain[index]
        label = self.labels[index]
        img = pil_loader(path)

        img = crop_img(img, bbox, mode='train')

        if self.transform is not None:
            img = self.transform(img)
        return path, img, target, label

    def __len__(self):
        return len(self.images)

class BoxOnlineDataset(object):
    def __init__(self, root, transforms, num_classes=10):
        self.root = root
        self.ann = self.get_all_ann()
        self.transform = transforms
        self.num_classes = num_classes

        self.images, self.bboxes, self.targets, self.cls_to_id, self.domain = self.filter_images(self.ann)

        print('images number: {}, num classes: {}'.format(len(self.images), self.num_classes))

    def get_all_ann(self):
        images = []
        anns = []
        ann_paths = [
            '/home/admin/workspace/myspace/train/i_train.json',
            '/home/admin/workspace/myspace/train/v_train.json',
        ]
        image_paths = [
            '/home/admin/workspace/myspace/train/images',
            '/home/admin/workspace/myspace/train/video_images',
        ]
        for i, path in enumerate(ann_paths):
            with open(path, 'r') as f:
                res = json.load(f)
            for item in res['images']:
                item['file_name'] = os.path.join(
                    image_paths[i],
                    item['file_name']
                )
                images.append(item)
            for item in res['annotations']:
                anns.append(item)
        return {'images': images, 'annotations': anns}

    def get_all_in(self, df):
        ins = df['instance_id'].unique()
        ok_num = 0
        ok_ins = []
        for id in ins:
            if id == 0:
                continue
            if len(df[df['instance_id'] == id]['type'].unique()) > 1:
                ok_num += 1
                ok_ins.append(id)
        print(f'all in: {ok_num}, all ins: {len(ins)}, ratio: {ok_num/len(ins)}')
        return ok_ins

    def filter_images(self, ann):
        ann_df = pd.DataFrame(ann['annotations'])
        img_df = pd.DataFrame(ann['images'])
        merge_df = ann_df.merge(img_df, how='left', left_on='image_id', right_on='id')
        merge_df['type'] = merge_df['file_name'].apply(lambda x: x.split('/')[-1][0])
        instance_ids = self.get_all_in(merge_df)
        inds = merge_df.instance_id.isin(instance_ids)
        images = merge_df.loc[inds, 'file_name'].tolist()
        bboxes = merge_df.loc[inds, 'bbox'].tolist()
        bboxes = [[x, y, x + w, y + h] for x, y, w, h in bboxes]
        targets = merge_df.loc[inds, 'instance_id'].tolist()
        domain = merge_df.loc[inds, 'type'].tolist()
        cls_to_id = {instance: id for id, instance in enumerate(instance_ids)}

        targets = [cls_to_id[cls] for cls in targets]

        # images = [os.path.join(self.root, name) for name in images]

        self.num_classes = len(instance_ids)
        return images, bboxes, targets, cls_to_id, domain

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path = self.images[index]
        bbox = self.bboxes[index]
        target = self.targets[index]
        img = pil_loader(path)

        img = crop_img(img, bbox)

        if self.transform is not None:
            img = self.transform(img)
        return path, img, target

    def __len__(self):
        return len(self.images)



class BoxAllDataset(object):
    def __init__(self, root, ann_path, transforms, num_classes=10):
        self.root = root
        self.ann = self.get_all_ann(ann_path)
        self.transform = transforms
        self.num_classes = num_classes

        self.images, self.bboxes, self.targets, self.cls_to_id, self.domain = self.filter_images(self.ann)

        print('images number: {}, num classes: {}'.format(len(self.images), self.num_classes))

    def get_all_ann(self, ann_path):
        images = []
        anns = []
        ann_paths = ['/PublicData/glt/contest/taobao/data/train_dataset_part{}/annotations/trainval.json'.format(i) \
            for i in ann_path]
        image_paths = ['/PublicData/glt/contest/taobao/data/train_dataset_part{}/images'.format(i) \
            for i in ann_path]
        for i, path in enumerate(ann_paths):
            with open(path, 'r') as f:
                res = json.load(f)
            for item in res['images']:
                item['id'] += int(i * 1e8)
                item['file_name'] = os.path.join(
                    image_paths[i],
                    item['file_name']
                )
                images.append(item)
            for item in res['annotations']:
                # item['id'] += i * 1e8
                item['image_id'] += int(i * 1e8)
                anns.append(item)
        return {'images': images, 'annotations': anns}        

    def get_all_in(self, df):
        ins = df['instance_id'].unique()
        ok_num = 0
        ok_ins = []
        for id in ins:
            if id == 0:
                continue
            if len(df[df['instance_id'] == id]['type'].unique()) > 1:
                ok_num += 1
                ok_ins.append(id)
        print(f'all in: {ok_num}, all ins: {len(ins)}, ratio: {ok_num/len(ins)}')
        return ok_ins

    def filter_images(self, ann):
        ann_df = pd.DataFrame(ann['annotations'])
        img_df = pd.DataFrame(ann['images'])
        merge_df = ann_df.merge(img_df, how='left', left_on='image_id', right_on='id')
        merge_df['type'] = merge_df['file_name'].apply(lambda x: x.split('/')[-1][0])
        instance_ids = self.get_all_in(merge_df)
        inds = merge_df.instance_id.isin(instance_ids)
        images = merge_df.loc[inds, 'file_name'].tolist()
        bboxes = merge_df.loc[inds, 'bbox'].tolist()
        bboxes = [[x, y, x + w, y + h] for x, y, w, h in bboxes]
        targets = merge_df.loc[inds, 'instance_id'].tolist()
        domain = merge_df.loc[inds, 'type'].tolist()
        cls_to_id = {instance: id for id, instance in enumerate(instance_ids)}

        targets = [cls_to_id[cls] for cls in targets]

        # images = [os.path.join(self.root, name) for name in images]

        self.num_classes = len(instance_ids)
        return images, bboxes, targets, cls_to_id, domain

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path = self.images[index]
        bbox = self.bboxes[index]
        target = self.targets[index]
        img = pil_loader(path)

        img = crop_img(img, bbox)

        if self.transform is not None:
            img = self.transform(img)
        return path, img, target

    def __len__(self):
        return len(self.images)



class BoxValDataset(object):
    def __init__(self, root, ann_path, transforms):
        self.root = root
        if 'validation_dataset_part3' in ann_path:
            self.type = 3
        elif 'validation_dataset_part4' in ann_path:
            self.type = 4
        else:
            self.type = 0
        with open(ann_path, 'r') as f:
            self.ann = json.load(f)
        if self.type in [3, 4]:
            with open('/PublicData/glt/contest/taobao/data/validation_gt_round2.json', 'r') as f:
                self.gt_round2 = json.load(f)
        print(self.type)
        self.transform = transforms

        self.images, self.bboxes, self.labels, self.targets= self.filter_images(self.ann)


    def filter_images(self, ann):
        ann_df = pd.DataFrame(ann['annotations'])
        img_df = pd.DataFrame(ann['images'])
        merge_df = ann_df.merge(img_df, how='left', left_on='image_id', right_on='id')

        images = merge_df['file_name'].tolist()
        bboxes = merge_df['bbox'].tolist()
        bboxes = [[x, y, x + w, y + h] for x, y, w, h in bboxes]
        targets = merge_df['instance_id'].tolist()
        labels = merge_df['category_id'].tolist()

        images = [os.path.join(self.root, name) for name in images]

        return images, bboxes, labels, targets

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path = self.images[index]
        bbox = self.bboxes[index]
        label = self.labels[index]
        target = self.targets[index]
        img = pil_loader(path)
        img = crop_img(img, bbox)
        file_name = path.split('/')[-1]
        name = file_name.split('_')[1]
        if self.type in [3, 4] and name in self.gt_round2:
            item_id = self.gt_round2[name]['item_id']
            file_name = file_name.replace(name, item_id)
        if self.transform is not None:
            img = self.transform(img)

        input = {}
        input['path'] = file_name
        input['image'] = img
        input['bbox'] = np.hstack([np.array(bbox), np.array(label), np.array(target)])
        return input

    def __len__(self):
        return len(self.images)

class BoxTestDataset(object):
    def __init__(self, root, ann_path, transforms):
        self.root = root
        with open(ann_path, 'r') as f:
            self.ann = json.load(f)
        self.transform = transforms

        self.images, self.bboxes, self.scores, self.targets= self.filter_images(self.ann)
        print('all crop images num: {}'.format(len(self.images)))


    def filter_images(self, ann):
        ann_df = pd.DataFrame(ann['annotations'])
        img_df = pd.DataFrame(ann['images'])
        merge_df = ann_df.merge(img_df, how='left', left_on='image_id', right_on='id')

        images = merge_df['file_name'].tolist()
        bboxes = merge_df['bbox'].tolist()
        bboxes = [[x, y, x + w, y + h] for x, y, w, h in bboxes]
        scores = merge_df['score'].tolist()
        # targets = merge_df['instance_id'].tolist()
        targets = merge_df['category_id'].tolist()

        images = [os.path.join(self.root, name) for name in images]

        return images, bboxes, scores, targets

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        score = self.scores[index]
        path = self.images[index]
        bbox = self.bboxes[index]
        target = self.targets[index]
        img = pil_loader(path)
        img = crop_img(img, bbox)

        if self.transform is not None:
            img = self.transform(img)

        input = {}
        input['path'] = path.split('/')[-1]
        input['image'] = img
        input['bbox'] = np.hstack([np.array(bbox), np.array(score), np.array(target)])
        return input

    def __len__(self):
        return len(self.images)
