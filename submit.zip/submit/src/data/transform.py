from PIL import Image, ImageOps
import cv2
import numpy as np
from torchvision import transforms

class Padding(object):

    def __init__(self, fill=(255,255,255)):
        self.fill = fill

    def __call__(self, img):
        w, h = img.size
        if w < h:
            boder_left = (h - w) // 2
            boder_right = (h - w) // 2
            boder_top = 0
            boder_bottom = 0
        else:
            boder_top = (w - h) // 2
            boder_bottom = (w - h) // 2
            boder_left = 0
            boder_right = 0
        img = ImageOps.expand(img, border=(boder_left, boder_top, boder_right, boder_bottom), 
                        fill=(255, 255,255))##left,top,right,bottom
        return img
