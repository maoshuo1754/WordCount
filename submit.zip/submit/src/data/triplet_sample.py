# encoding: utf-8
"""
@author:  liaoxingyu
@contact: liaoxingyu2@jd.com
"""

import copy
import random
import torch
from collections import defaultdict

import numpy as np
from torch.utils.data.sampler import Sampler
import pdb


class RandomIdentitySampler(Sampler):
    """
    Randomly sample N identities, then for each identity,
    randomly sample K instances, therefore batch size is N*K.
    Args:
    - data_source (list): list of (img_path, pid, camid).
    - num_instances (int): number of instances per identity in a batch.
    - batch_size (int): number of examples in a batch.
    """

    def __init__(self, data_source, domain, batch_size, num_instances, pair=(1, 2)):
        self.data_source = data_source
        self.domain = domain
        assert(len(data_source) == len(domain))
        assert(pair[0] + pair[1] == num_instances)
        self.pair_v = pair[0]  # (v, i) match pair number
        self.pair_i = pair[1] # (v, i) match pair number
        self.batch_size = batch_size
        self.num_instances = num_instances
        self.num_pids_per_batch = self.batch_size // self.num_instances
        self.index_dic = defaultdict(list)
        self.index_dic_v = defaultdict(list)
        for index, pid in enumerate(self.data_source):
            if self.domain[index] == 'i':
                self.index_dic[pid].append(index)
            else:
                self.index_dic_v[pid].append(index)
        self.pids = list(self.index_dic.keys())

        # estimate number of examples in an epoch
        self.length = 0
        for pid in self.pids:
            idxs = self.index_dic[pid]
            num = len(idxs)
            if num < self.num_instances:
                num = self.num_instances
            self.length += num - num % self.num_instances

    def __iter__(self):
        batch_idxs_dict = defaultdict(list)
        for pid in self.pids:
            idxs_i = copy.deepcopy(self.index_dic[pid])
            idxs_v = copy.deepcopy(self.index_dic_v[pid])
            if len(idxs_v) == 0:
                idxs_v = idxs_i[:len(idxs_i)//2]
                idxs_i = idxs_i[len(idxs_i)//2:]
            if len(idxs_i) == 0:
                idxs_i = idxs_v[:len(idxs_v)//2]
                idxs_v = idxs_v[len(idxs_v)//2:]
            if len(idxs_i) < self.pair_i:
                idxs_i = np.random.choice(idxs_i, size=self.pair_i, replace=True)
            if len(idxs_v) < len(idxs_i):
                idxs_v = np.random.choice(idxs_v, size=len(idxs_i), replace=True)
            if len(idxs_v) < self.pair_v:
                idxs_v = np.random.choice(idxs_v, size=self.pair_v, replace=True)
            random.shuffle(idxs_i)
            random.shuffle(idxs_v)
            batch_idxs = []
            for i, idx in enumerate(idxs_i):
                batch_idxs.append(idx)
                if i % (self.pair_i // self.pair_v) == 0:
                    batch_idxs.append(idxs_v[i])
                if len(batch_idxs) == self.num_instances:
                    random.shuffle(batch_idxs)
                    batch_idxs_dict[pid].append(batch_idxs)
                    batch_idxs = []

        avai_pids = copy.deepcopy(self.pids)
        final_idxs = []

        while len(avai_pids) >= self.num_pids_per_batch:
            selected_pids = random.sample(avai_pids, self.num_pids_per_batch)
            for pid in selected_pids:
                batch_idxs = batch_idxs_dict[pid].pop(0)
                final_idxs.extend(batch_idxs)
                if len(batch_idxs_dict[pid]) == 0:
                    avai_pids.remove(pid)

        self.length = len(final_idxs)
        return iter(final_idxs)

    def __len__(self):
        return self.length



class RandomIdentitySamplerCls(Sampler):
    """
    Randomly sample N identities, then for each identity,
    randomly sample K instances, therefore batch size is N*K.
    Args:
    - data_source (list): list of (img_path, pid, camid).
    - num_instances (int): number of instances per identity in a batch.
    - batch_size (int): number of examples in a batch.
    """

    def __init__(self, data_source, domain, labels, batch_size, num_instances, pair=(1, 2)):
        self.data_source = data_source
        self.domain = domain
        assert(len(data_source) == len(domain))
        assert(pair[0] + pair[1] == num_instances)
        self.pair_v = pair[0]  # (v, i) match pair number
        self.pair_i = pair[1] # (v, i) match pair number
        self.batch_size = batch_size
        self.num_instances = num_instances
        self.num_pids_per_batch = self.batch_size // self.num_instances
        self.index_dic = defaultdict(list)
        self.index_dic_v = defaultdict(list)
        for index, pid in enumerate(self.data_source):
            if self.domain[index] == 'i':
                self.index_dic[pid].append(index)
            else:
                self.index_dic_v[pid].append(index)
        self.pids = list(self.index_dic.keys())

        # estimate number of examples in an epoch
        self.length = 0
        for pid in self.pids:
            idxs = self.index_dic[pid]
            num = len(idxs)
            if num < self.num_instances:
                num = self.num_instances
            self.length += num - num % self.num_instances

        self.cls_pid = {}
        for i, pid in enumerate(self.data_source):
            label = labels[i]
            if label not in self.cls_pid:
                self.cls_pid[label] = set()
            self.cls_pid[label].add(pid)
        self.labels = list(self.cls_pid.keys())

    def __iter__(self):
        batch_idxs_dict = defaultdict(list)
        for pid in self.pids:
            idxs_i = copy.deepcopy(self.index_dic[pid])
            idxs_v = copy.deepcopy(self.index_dic_v[pid])
            if len(idxs_v) == 0:
                idxs_v = idxs_i[:len(idxs_i)//2]
                idxs_i = idxs_i[len(idxs_i)//2:]
            if len(idxs_i) == 0:
                idxs_i = idxs_v[:len(idxs_v)//2]
                idxs_v = idxs_v[len(idxs_v)//2:]
            if len(idxs_i) < self.pair_i:
                idxs_i = np.random.choice(idxs_i, size=self.pair_i, replace=True)
            if len(idxs_v) < len(idxs_i):
                idxs_v = np.random.choice(idxs_v, size=len(idxs_i), replace=True)
            if len(idxs_v) < self.pair_v:
                idxs_v = np.random.choice(idxs_v, size=self.pair_v, replace=True)
            random.shuffle(idxs_i)
            random.shuffle(idxs_v)
            batch_idxs = []
            for i, idx in enumerate(idxs_i):
                batch_idxs.append(idx)
                if i % (self.pair_i // self.pair_v) == 0:
                    batch_idxs.append(idxs_v[i])
                if len(batch_idxs) == self.num_instances:
                    random.shuffle(batch_idxs)
                    batch_idxs_dict[pid].append(batch_idxs)
                    batch_idxs = []

        avai_labels = copy.deepcopy(self.labels)
        avai_cls_pids = copy.deepcopy(self.cls_pid)
        final_idxs = []
        pdb.set_trace()
        while self.sum(avai_cls_pids) >= self.num_pids_per_batch:
            label = random.sample(avai_labels, 1)[0]
            if len(avai_cls_pids[label]) < self.num_pids_per_batch:
                selected_pids = random.sample(avai_cls_pids[label], self.num_pids_per_batch)
            else:
                selected_pids = random.sample(avai_cls_pids[label], self.num_pids_per_batch)

            for pid in selected_pids:
                batch_idxs = batch_idxs_dict[pid].pop(0)
                final_idxs.extend(batch_idxs)
                if len(batch_idxs_dict[pid]) == 0:
                    avai_cls_pids[label].remove(pid)
                    if len(avai_cls_pids[label]) == 0:
                        avai_labels.remove(label)

        self.length = len(final_idxs)
        return iter(final_idxs)

    def sum(self, avai_cls_pids):
        s = 0
        for _, value in avai_cls_pids.items():
            s += len(value)
        return s

    def __len__(self):
        return self.length


