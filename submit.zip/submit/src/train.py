import math
import time
import os
import torch
import torch.nn as nn
import numpy as np
from tqdm import tqdm
import pickle
import pdb
import argparse
from data.build import build_dataloader, build_dataset, build_val_dataloader, build_test_dataloader
from loss.build import build_loss
from model.build import build_lr_scheduler, build_model, build_optimizer
from util.logger import setup_logger
from util.metrics import metric


def parse_args():
    parser = argparse.ArgumentParser(
        description='Process a checkpoint to be published')
    parser.add_argument('--mode', default='train', dest='mode',)
    parser.add_argument('--pos', default='tianchi', dest='pos',)
    parser.add_argument('--gpus', default='4,5,6,7', dest='gpus',)
    parser.add_argument('--input_size_h', default=224, type=int, dest='input_size_h',)
    parser.add_argument('--input_size_w', default=224, type=int, dest='input_size_w',)
    parser.add_argument('--flip', default=0, type=int, dest='flip',)
    parser.add_argument('--root', default='/PublicData/glt/contest/taobao/data/train_dataset_part1/images', dest='root',)
    parser.add_argument('--ann_path',
        default='/PublicData/glt/contest/taobao/data/train_dataset_part1/annotations/trainval.json', dest='ann_path',)
    parser.add_argument('--num_epochs', default=100, type=int, dest='num_epochs',)
    parser.add_argument('--margin', default=0.3, type=float, dest='margin',)
    parser.add_argument('--dataset', default='1', dest='dataset',)
    parser.add_argument('--SAVED_PIRIOD', default=10, type=int, dest='SAVED_PIRIOD',)
    parser.add_argument('--VAL_PIRIOD', default=10, type=int, dest='VAL_PIRIOD',)
    parser.add_argument('--batch_size', default=48*4, type=int, dest='batch_size',)
    parser.add_argument('--num_instances', default=3, type=int, dest='num_instances',)
    parser.add_argument('--num_classes', default=5000, type=int, dest='num_classes',)
    parser.add_argument('--model_name', default='resnet50', dest='model_name',)
    parser.add_argument('--gem_pool', default='on', dest='gem_pool',)
    parser.add_argument('--pretrain_path', default='/home/glt/.cache/torch/checkpoints/resnet50-19c8e357.pth', dest='pretrain_path',)
    parser.add_argument('--checkpoint_path',
        default='/PublicData/glt/contest/taobao/work_dirs/retrieval/resnet50_1v2i_nopad_more_epoch_ep119.pth', dest='checkpoint_path',)
    parser.add_argument('--log_dir',
        default='/PublicData/glt/contest/taobao/work_dirs/retrieval', dest='log_dir',)
    parser.add_argument('--snap', default='resnet50_ibn_2i1v_gem_73_ranger_20_40_60_35e-5', dest='snap',)
    parser.add_argument('--output', default='resnet50_large_bz_auto_aug.pkl', dest='output',)

    args = parser.parse_args()
    return args

def config_info(cfg, logger):
    for key, value in cfg._get_kwargs():
        logger.info(f'{key}: {value}')

def run_val(model, dataloader):
    model.eval()
    feats = []
    paths = []
    bboxes = []
    for i, input in tqdm(enumerate(dataloader), total=len(dataloader)):
        img = input['image']
        img = img.cuda()
        with torch.no_grad():
            feature = model(img)
        feature = feature.cpu().numpy()
        paths += input['path']
        feats.append(feature)
        bboxes.append(input['bbox'].numpy())
    
    bboxes = np.vstack(bboxes)
    feats = np.vstack(feats)

    res_focus = metric(paths, feats, bboxes, val=True)
    res_all = metric(paths, feats, bboxes, val=False)
    return res_focus, res_all

def do_train(cfg):
    logger = setup_logger(cfg.snap, cfg.log_dir, 0)
    config_info(cfg, logger)

    dataset = build_dataset(cfg)
    cfg.num_classes = dataset.num_classes
    dataloader = build_dataloader(cfg, dataset)
    val_dataloader = build_val_dataloader(cfg)
    model = build_model(cfg)
    model = model.cuda()
    model = nn.DataParallel(model)
    
    criterion = build_loss(cfg)
    optimizer = build_optimizer(cfg, model)
    scheduler = build_lr_scheduler(cfg, optimizer)
    
    since = time.time()

    for epoch in range(cfg.num_epochs):
        logger.info('Epoch {}/{}'.format(epoch, cfg.num_epochs - 1))

        # Each epoch has a training and validation phase
        model.train()  # Set model to training mode
        running_loss = 0.0
        running_loss_all = np.zeros(shape=(3))
        running_corrects = 0
        all_preds = torch.empty([0]).int()
        all_labels = torch.empty([0]).int()
        # Iterate over data.
        for name, inputs, labels in tqdm(dataloader):
            optimizer.zero_grad()
            inputs = inputs.cuda()
            labels = labels.cuda()

            logit, global_feat = model(inputs, labels)
            loss, record_loss = criterion(logit, global_feat, labels)

            _, preds = torch.max(logit, 1)

            loss.backward()
            optimizer.step()

            all_preds = torch.cat([all_preds, preds.cpu().int()], 0)
            all_labels = torch.cat([all_labels, labels.data.cpu().int()], 0)
            # statistics
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

            for i, l in enumerate(record_loss):
                running_loss_all[i] += l.item() * inputs.size(0)

        epoch_loss = running_loss / len(dataloader.sampler)
        epoch_loss_all = running_loss_all / len(dataloader.sampler)
        epoch_acc = running_corrects.double() / len(dataloader.sampler)
        all_labels = all_labels.numpy()
        all_preds = all_preds.numpy()
        logger.info('train lr: {:.7f} cls Loss: {:.6f} Acc: {:.6f} cls Loss: {:.6f} triplet loss: {:.6f}'.format(
            scheduler.get_lr()[0], epoch_loss, epoch_acc, epoch_loss_all[0], epoch_loss_all[1]))

        if (epoch + 1) % cfg.SAVED_PIRIOD == 0:
            torch.save({
                'epoch': epoch,
                'state_dict': model.module.state_dict(),
            },
            os.path.join(cfg.log_dir, cfg.snap,'ckpt_ep{}.pth'.format(epoch)))

        if (epoch + 1) % cfg.VAL_PIRIOD == 0:
            res_focus, res_all = run_val(model, val_dataloader)
            logger.info('val select top5, focus acc: {:.6f}, all acc: {:.6f}'.format(res_focus, res_all))

        if scheduler is not None:  # after val at this epoch
            scheduler.step()

        logger.info('\n')
    time_elapsed = time.time() - since
    logger.info('{} - Training complete in {:.0f}m {:.0f}s'.format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        time_elapsed // 60, time_elapsed % 60))


def do_val(cfg):
    dataloader = build_val_dataloader(cfg)
    model = build_model(cfg)
    model = model.cuda()
    if torch.cuda.device_count() > 0:
        model = nn.DataParallel(model)
    
    res_focus, res_all = run_val(model, dataloader)
    print('val select top5, focus acc: {:.6f}, all acc: {:.6f}'.format(res_focus, res_all))


def infrence(cfg):
    dataloader = build_test_dataloader(cfg)

    model = build_model(cfg)
    model = model.cuda()
    if torch.cuda.device_count() > 0:
        model = nn.DataParallel(model)
    
    model.eval()
    feats = []
    paths = []
    bboxes = []
    for i, input in tqdm(enumerate(dataloader), total=len(dataloader)):
        img = input['image']
        img = img.cuda()
        with torch.no_grad():
            feature = model(img)
        feature = feature.cpu().numpy()
        paths += input['path']
        feats.append(feature)
        bboxes.append(input['bbox'].numpy())
    
    bboxes = np.vstack(bboxes)
    feats = np.vstack(feats)
    # output = os.path.join(cfg.log_dir, cfg.output)
    with open(cfg.output, 'wb') as f:
        pickle.dump(
            {
                'images': paths,
                'bbox':bboxes,
                'feat': feats,
            },
            f
        )

def main(cfg):
    if cfg.mode == 'train':
        do_train(cfg)
    elif cfg.mode == 'val':
        do_val(cfg)
    elif cfg.mode == 'test':
        infrence(cfg)

if __name__ == "__main__":
    cfg = parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = cfg.gpus
    torch.backends.cudnn.benchmark = True
    main(cfg)