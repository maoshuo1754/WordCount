from .loss import TripletLoss, CrossEntropyLabelSmooth, TripletLoss2, MultiSimilarityLoss
from torch import nn
import torch.nn.functional as F
from .xbm import CrossBatchMemory

def build_loss(cfg):
    margin = cfg.margin if cfg.margin != 0 else None
    if cfg.pair_loss_type == 'MS':
        print('cfg.pair_loss_type == MS')
        triplet = MultiSimilarityLoss()
    else:
        triplet = TripletLoss(margin=margin)
    # triplet = TripletLoss2(margin=margin)
    if cfg.label_smooth:
        id_loss_func = CrossEntropyLabelSmooth(cfg.num_classes)
        print('Label Smoothing on')
    else:
        id_loss_func = F.cross_entropy
    
    # xbm = CrossBatchMemory(triplet, 2048, 1024)

    # def loss_xbm(logit, feat, target, epoch):
    #     if epoch < 50:
    #         id_loss = id_loss_func(logit, target)
    #         metric_loss = triplet(feat, target)
    #         return  id_loss * cfg.ce_weight + metric_loss * cfg.triplet_weight, (id_loss, metric_loss)
    #     else:
    #         return xbm(logit, feat, target)

    def loss_func(logit, feat, target):
        id_loss = id_loss_func(logit, target)
        metric_loss = triplet(feat, target)
        return  id_loss * cfg.ce_weight + metric_loss * cfg.triplet_weight, (id_loss, metric_loss)

    return loss_func
