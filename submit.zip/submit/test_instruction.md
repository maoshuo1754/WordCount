# 推理代码说明

整体推理脚本：`sh run_test.sh`

## 数据预处理

```shell
python tools/gen_det_ann_fs.py
```

- tools/gen_det_ann_fs.py
  - 对测试集 video 数据进行分帧，每隔 40 帧保存一次图像
  - 对测试集所有图像进行统一命名
    - i_filename_itemid.jpg
    - v_itemid_frameindex.jpg

## 检测部分

```shell
# 对 images 进行测试
python mmdetection/tools/test.py config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_i.py /myspace/mmdet/image/images_cascade.pth \
	--format_only --options "jsonfile_prefix=/myspace/mmdet/result/i_fs_cascade"

python tools/json_taobao_2_submit.py \
	--input /myspace/mmdet/result/i_fs_cascade.bbox.json \
	--ann /myspace/test_dataset_fs/annotations/test_image.json \
	--output /myspace/mmdet/result/i_fs_cascade.json

# 对 video images 进行测试
python mmdetection/tools/test.py config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_v.py /myspace/mmdet/image/videos_cascade.pth \
	--format_only --options "jsonfile_prefix=/myspace/mmdet/result/v_fs_cascade"

python tools/json_taobao_2_submit.py \
	--input /myspace/mmdet/result/v_fs_cascade.bbox.json \
	--ann /myspace/test_dataset_fs/annotations/test_video.json \
	--output /myspace/mmdet/result/v_fs_cascade.json

python tools/filter_ann.py
```

- 使用 mmdetection 进行测试
- tools/json_taobao_2_submit.py
  - 将测试结果转换为 COCO 标准格式
- tools/filter_ann.py
  - 对最后结果进行一次过滤，去除掉整张图里面所有 bbox 得分都很小的图像

## 检索部分

以单模型为例：对测试集的image和 video images分别进行预测，并使用 TTA，预测左右flip后的图像，最终分别保存结果。

```shell
# rs101_alll_circle_386_198_19_lr
python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 1

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/images \
	--ann_path /myspace/mmdet/result/i_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0

python src/train.py --mode test --gpus 0 --batch_size 512 \
	--root /myspace/test_dataset_fs/video_images \
	--ann_path /myspace/mmdet/result/v_fs_cascade_filter.json \
	--model_name resnest101 \
	--gem_pool on \
	--checkpoint_path /checkpoints/rs101_alll_circle_386_198_19_lr.pth \
	--output /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr.pkl \
	--input_size_h 386 \
	--input_size_w 198 \
	--flip 0
```

- src/train.py

  - root：图像所在路径
  - ann_path：检测结果所在路径
  - model_name：模型名称
  - gem_pool：是否开启 gem
  - checkpoint_path：模型权重路径
  - output：输出结果路径
  - input_size_h：输入图像高度
  - input_size_w：输入图像宽度
  - flip：是否左右翻转

## 搜索匹配

```shell
python tools/search_f1_merge_dist_frame.py \
	--feat_path1 /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr.pkl /myspace/feat/i_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr.pkl /myspace/feat/i_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr.pkl /myspace/feat/i_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr.pkl /myspace/feat/i_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr.pkl /myspace/feat/i_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--feat_path2 /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr.pkl /myspace/feat/v_fs_feat_r101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr.pkl /myspace/feat/v_fs_feat_se101_alll_circle_386_198_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr.pkl /myspace/feat/v_fs_feat_rx101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_rx101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr.pkl /myspace/feat/v_fs_feat_rs101_alll_circle_386_198_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_rs101_alll_circle_256_256_19_lr_flip.pkl \
				/myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr.pkl /myspace/feat/v_fs_feat_se101_alll_circle_256_256_19_lr_flip.pkl \
	--steps 3 2 2 2 2 \
	--output result.json
```

- tools/search_f1_merge_dist_frame.py：搜索匹配与模型融合
  - feat_path1：images 的特征所在路径，以空格分离不同模型结果
  - feat_path2：video images 的特征所在路径，以空格分离不同模型结果
  - steps：rerank 的参数
  - output：结果输出文件

