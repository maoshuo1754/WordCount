# 训练代码说明

整体训练过程：
```shell
sh run_train_data_processing.sh
sh run_train_det.sh
sh run_train_retrieval.sh
```

## 数据预处理

- tools/process_data_train.py
  - 对视频进行分帧，保存为图像
  - 整合 image 和 video 的标注文件为 coco 标准格式
  - 对image和video的图像进行统一命名
    - i_filename_itemid.jpg
    - v_itemid_frameindex.jpg
- tools/merge_dataset.py
  - 把所有训练集 part 进行合并
- tools/change_num_classes.py
  - 改变训练集 json 中类别数量，变为2分类任务，仅仅检测是否为目标
- 数据预处理脚本：
  - `sh run_train_data_processing.sh`

## 检测部分

所以检测相关核心代码放在 mmdetection 文件夹下

- 使用 mmdetection-v1.2 检测框架
  - 具体环境配置查看 https://github.com/open-mmlab/mmdetection/blob/v1.2.0/docs/INSTALL.md
- config 文件
  - image：config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_i.py
  - video：config/cascade_rcnn_dconv_c3-c5_r50_fpn_1x_v.py
- 预训练权重下载地址：
  - https://s3.ap-northeast-2.amazonaws.com/open-mmlab/mmdetection/models/cascade_rcnn_r50_fpn_20e_20181123-db483a09.pth
- 训练脚本
  - `sh run_train_det.sh`

## 检索部分

所有检索相关核心代码放在 src 文件夹下

- src/config 文件夹下放置所有检索模型的配置文件
- 预训练权重下载地址
  - r101_ibn/rx101_ibn/se101_ibn：https://drive.google.com/drive/folders/1thS2B8UOSBi_cJX6zRy6YYRwz_nVFI_S
  - resnest 101 下载地址：https://hangzh.s3.amazonaws.com/encoding/models/22405ba7-resnest101.pth
- 训练脚本
  - `sh run_train_retrieval.sh`

