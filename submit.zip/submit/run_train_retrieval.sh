#!/bin/bash
start_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
export PYTHONIOENCODING=utf-8

python src/main.py \
	--mode train \
	--cfg_name online_r101_386_198

ls -lh /myspace/work_dirs/retrieval/online_r101_386_198

python src/main.py \
	--mode train \
	--cfg_name online_rx101_386_198

ls -lh /myspace/work_dirs/retrieval/online_rx101_386_198

python src/main.py \
	--mode train \
	--cfg_name online_rx101_256_256

ls -lh /myspace/work_dirs/retrieval/online_rx101_256_256

python src/main.py \
	--mode train \
	--cfg_name online_rs101_386_198

ls -lh /myspace/work_dirs/retrieval/online_rs101_386_198


python src/main.py \
	--mode train \
	--cfg_name online_rs101_256_256

ls -lh /myspace/work_dirs/retrieval/online_rs101_256_256

python src/main.py \
	--mode train \
	--cfg_name online_se101_386_198

ls -lh /myspace/work_dirs/retrieval/online_se101_386_198

python src/main.py \
	--mode train \
	--cfg_name online_se101_256_256

ls -lh /myspace/work_dirs/retrieval/online_se101_256_256

finish_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time")-$(date +%s -d "$start_time")))))
echo "****************this shell script execution duration: $duration"
