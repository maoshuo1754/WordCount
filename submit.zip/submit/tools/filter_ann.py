from mmdet.ops.nms import nms
import mmcv
import os
import json
import numpy as np
import pdb

ann1 = mmcv.load('/myspace/mmdet/result/i_fs_cascade.json')
ann2 = mmcv.load('/myspace/mmdet/result/v_fs_cascade.json')

res1 = {}
for item in ann1['annotations']:
    img_id = item['image_id']
    if img_id not in res1:
        res1[img_id] = []
    res1[img_id].append(item)

ann_res1 = []
id = 0
flag = False
for key, items in res1.items():
    for item in items:
        if item['score'] > 0.8:
            flag = True
            break
    if flag:
        ann_res1 += items
    flag = False

print('anns {} => {}'.format(len(ann1['annotations']), len(ann_res1)))

ann1['annotations'] = ann_res1
mmcv.dump(ann1, '/myspace/mmdet/result/i_fs_cascade_filter.json')

res2 = {}
for item in ann2['annotations']:
    img_id = item['image_id']
    if img_id not in res2:
        res2[img_id] = []
    res2[img_id].append(item)

ann_res2 = []
id = 0
flag = False
for key, items in res2.items():
    for item in items:
        if item['score'] > 0.8:
            flag = True
            break
    if flag:
        ann_res2 += items
    flag = False

print('anns {} => {}'.format(len(ann2['annotations']), len(ann_res2)))

ann2['annotations'] = ann_res2
mmcv.dump(ann2, '/myspace/mmdet/result/v_fs_cascade_filter.json')
