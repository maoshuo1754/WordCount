import faiss
import numpy as np
from sklearn.preprocessing import normalize
import pdb

class QE:
    """
    Combining the retrieved topk nearest neighbors with the original query and doing another retrieval.
    c.f. https://www.robots.ox.ac.uk/~vgg/publications/papers/chum07b.pdf
    Hyper-Params:
        qe_times (int): number of query expansion times.
        qe_k (int): number of the neighbors to be combined.
    """

    def __init__(self, qe_times=1, qe_k=5):
        """
        Args:
            hps (dict): default hyper parameters in a dict (keys, values).
        """
        self.qe_times = qe_times
        self.qe_k = qe_k

    def knn(self, qf, gf, top_k):
        index = faiss.IndexFlatIP(gf.shape[1])
        index.add(gf)
        D, I = index.search(qf, top_k)
        return D, I

    def __call__(self, query_fea, gallery_fea):
        print('start query, query_fea.shape = {}, gallery_fea.shape = {}, qe_times = {}, qe_k = {}'.format(
            query_fea.shape, gallery_fea.shape, self.qe_times, self.qe_k))
        for i in range(self.qe_times):
            _, sorted_index = self.knn(query_fea, gallery_fea, self.qe_k)
            sorted_index = sorted_index.reshape(-1)
            requery_fea = gallery_fea[sorted_index].reshape(query_fea.shape[0], -1, query_fea.shape[1]).sum(axis=1)
            requery_fea = requery_fea + query_fea
            query_fea = normalize(requery_fea)
            query_fea = requery_fea

        return query_fea