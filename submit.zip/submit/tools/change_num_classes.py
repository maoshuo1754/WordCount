import json

with open('/home/admin/workspace/myspace/train/i_train.json', 'r') as f:
    res_i = json.load(f)

for item in res_i['annotations']:
    item['category_id'] = 1

res_i['categories'] = res_i['categories'][:1]

print(res_i['categories'])

with open('/home/admin/workspace/myspace/train/i_train_1.json', 'w') as f:
    json.dump(res_i, f)

with open('/home/admin/workspace/myspace/train/v_train.json', 'r') as f:
    res_i = json.load(f)

for item in res_i['annotations']:
    item['category_id'] = 1

res_i['categories'] = res_i['categories'][:1]

print(res_i['categories'])

with open('/home/admin/workspace/myspace/train/v_train_1.json', 'w') as f:
    json.dump(res_i, f)