import json
import argparse
import pandas as pd

def parse_args():
    parser = argparse.ArgumentParser(
        description='Process a checkpoint to be published')
    parser.add_argument('--input', dest='input',)
    parser.add_argument('--ann', dest='ann',)
    parser.add_argument('--output', dest='output',)

    args = parser.parse_args()
    return args

args = parse_args()

test_json_raw = json.load(open(args.ann, "r"))
test_json = json.load(open('{}'.format(args.input), "r"))

test_json_raw['annotations'] = test_json

with open('{}'.format(args.output), 'w') as fp:
    json.dump(test_json_raw, fp)

dt_df = pd.DataFrame(test_json_raw['annotations'])
print('all images: ', len(test_json_raw['images']))
print('all unique image ann: ', len(dt_df['image_id'].unique()))
