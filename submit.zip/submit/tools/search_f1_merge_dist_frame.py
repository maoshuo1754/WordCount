import pickle
import numpy as np
from tqdm import tqdm
import pdb
import faiss
from collections import Counter, defaultdict
from sklearn.preprocessing import normalize
from tqdm import tqdm
import random
import json
import argparse

def parse_args():
    parser = argparse.ArgumentParser(
        description='Process a checkpoint to be published')
    parser.add_argument('--val', dest='val', type=int)
    parser.add_argument('--feat_path1', nargs='+', dest='feat_path1',)
    parser.add_argument('--feat_path2', nargs='+', dest='feat_path2',)
    parser.add_argument('--steps', nargs='+', type=int)
    parser.add_argument('--output', dest='output',)

    args = parser.parse_args()
    return args

def remove_idx(q_feat, g_feat, topK):
    # 返回在 g_feat 中需要保存的 索引
    index_remove = faiss.IndexFlatIP(g_feat.shape[1])   # build the index
    print(index_remove.is_trained)
    index_remove.add(g_feat)                  # add vectors to the index
    print(index_remove.ntotal)

    _, I = index_remove.search(q_feat, topK) # sanity check
    keep_idx = I.reshape((-1, ))
    keep_idx = np.unique(keep_idx)
    return keep_idx

def filter_feat(v_feat, i_feat, v_bbox, i_bbox, v_index_2_name, i_index_2_name, seq=[5,2,4,2,3]):
    for i, topk in enumerate(seq):
        if i % 2 == 0:
            v_keep_idx = remove_idx(i_feat, v_feat, topk)
            v_feat = v_feat[v_keep_idx]
            v_bbox = v_bbox[v_keep_idx]
            v_index_2_name = v_index_2_name[v_keep_idx]
        else:
            i_keep_idx = remove_idx(v_feat, i_feat, topk)
            i_feat = i_feat[i_keep_idx]
            i_bbox = i_bbox[i_keep_idx]
            i_index_2_name = i_index_2_name[i_keep_idx]
    return v_feat, i_feat, v_bbox, i_bbox, v_index_2_name, i_index_2_name

def split_vi_by_name(name):
    v_index = []
    i_index = []
    for i in range(len(names)):
        if names[i].startswith('v_'):
            v_index.append(i)
        else:
            i_index.append(i)
    return v_index, i_index

test_acc = True

args = parse_args()
Is = []
Ds = []
i_index_2_names = []
v_index_2_names = []
i_bboxes = []
v_bboxes = []
for model_id, _ in enumerate(args.feat_path1):
    v_index_2_name = []
    v_feat = []
    v_bbox = []
    i_index_2_name = []
    i_feat = []
    i_bbox = []
    names = []
    feat = []
    bbox = []
    path = args.feat_path1[model_id]
    print('feat path: ', path)
    with open(path, 'rb') as f:
        res = pickle.load(f)
    names += res['images']
    bbox.append(res['bbox'])
    feat.append(res['feat'])

    path = args.feat_path2[model_id]
    print('feat path: ', path)
    with open(path, 'rb') as f:
        res = pickle.load(f)
    names += res['images']
    bbox.append(res['bbox'])
    feat.append(res['feat'])

    names = np.array(names)
    feat = np.vstack(feat)
    bbox = np.vstack(bbox)

    v_index, i_index = split_vi_by_name(names)

    v_feat = feat[v_index]
    i_feat = feat[i_index]
    v_bbox = bbox[v_index]
    i_bbox = bbox[i_index]
    v_index_2_name = names[v_index]
    i_index_2_name = names[i_index]

    v_feat = normalize(v_feat, axis=1)
    i_feat = normalize(i_feat, axis=1)

    v_feat, i_feat, v_bbox, i_bbox, v_index_2_name, i_index_2_name = filter_feat(
        v_feat, i_feat, v_bbox, i_bbox, v_index_2_name, i_index_2_name, 
        # seq=[4,2,3,2,2])
        seq=args.steps)

    index = faiss.IndexFlatIP(v_feat.shape[1])   # build the index
    print(index.is_trained)
    index.add(i_feat)                  # add vectors to the index
    print(index.ntotal)

    k = 5                          # we want to see 4 nearest neighbors
    D, I = index.search(v_feat, k) # sanity check

    print(I.shape)
    print(D.shape)
    Is.append(I)
    Ds.append(D)
    i_index_2_names.append(i_index_2_name)
    v_index_2_names.append(v_index_2_name)
    i_bboxes.append(i_bbox)
    v_bboxes.append(v_bbox)

TOP = 2
res_dict = {}
res_idxs = []
all_v_num = []
for model_id in range(len(Is)):
    I = Is[model_id]
    D = Ds[model_id]
    i_index_2_name = i_index_2_names[model_id]
    v_index_2_name = v_index_2_names[model_id]
    top1_idx = I[:, :TOP]
    top1_dis = D[:, :TOP]
    top1_name = i_index_2_name[top1_idx]
    for i in tqdm(range(len(I))):
        v_name = v_index_2_name[i].split('_')[1]
        if v_name not in res_dict:
            res_dict[v_name] = {}
        score = 0
        i_names = []
        for m, name in enumerate(top1_name[i]):
            name = name.split('_')[2][:-4]
            if name not in res_dict[v_name]:
                res_dict[v_name][name] = 0
            res_dict[v_name][name] += top1_dis[i, m]
            i_names.append(name)
        if v_name not in all_v_num:
            all_v_num.append(v_name)

    res_idx = {}
    '''
    res_idx = {
        'v_name': {
            'i_name': [[v_idx], [i_idx]]
        }
    }
    '''
    for i in tqdm(range(len(I))):
        v_name = v_index_2_name[i].split('_')[1]
        if v_name not in res_idx:
            res_idx[v_name] = {}
        for i_id in top1_idx[i]:
            i_name = i_index_2_name[i_id].split('_')[2][:-4]
            if i_name not in res_idx[v_name]:
                res_idx[v_name][i_name] = [[], []]
            res_idx[v_name][i_name][0].append(i)
            res_idx[v_name][i_name][1].append(i_id)
    res_idxs.append(res_idx)
# filter num
score = {}
for v_name, counter in res_dict.items():
    most_common = sorted(counter.items(), key=lambda d:d[1])[-1:][::-1]
    i_name = [x[0] for x in most_common]
    score[v_name] = most_common[0]
sc = np.array([value[1] for value in score.values()])
sc = np.sort(sc)
split = 1200
print('sppppppppplllllllliiiiiiiiiiitttttttt: ', split)
sc_th = sc[split]

scores = np.array([0.83044444, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.86888889,
       0.86888889, 0.86888889, 0.86888889, 0.86888889, 0.84333333,
       0.84333333, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.90166667,
       0.90166667, 0.90166667, 0.90166667, 0.90166667, 0.88666667,
       0.88666667, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.93955556,
       0.93955556, 0.93955556, 0.93955556, 0.93955556, 0.91777778,
       0.91777778, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.95444444,
       0.95444444, 0.95444444, 0.95444444, 0.95444444, 0.92866667,
       0.92866667, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.95855556,
       0.95855556, 0.95855556, 0.95855556, 0.95855556, 0.93566667,
       0.93566667, 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.962     ,
       0.962     , 0.962     , 0.962     , 0.962     , 0.93566667,
       0.93566667, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.95822222,
       0.95822222, 0.95822222, 0.95822222, 0.95822222, 0.93188889,
       0.93188889, 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.954     ,
       0.954     , 0.954     , 0.954     , 0.954     , 0.928     ,
       0.928     , 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.94744444,
       0.94744444, 0.94744444, 0.94744444, 0.94744444, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.92077778,
       0.92077778, 0.92077778, 0.92077778, 0.92077778, 0.        ])
def get_score(frame):
    try:
        return scores[frame]
    except:
        return 0

# make submit
v_top = 1
sub = {}

for v_name, counter in res_dict.items():
    most_common = sorted(counter.items(), key=lambda d:d[1])[-v_top:]

    i_name = most_common[0][0]
    if most_common[0][1] <= sc_th:
        continue
    for model_id in range(len(res_idxs)):
        res_idx = res_idxs[model_id]
        if v_name not in res_idx or i_name not in res_idx[v_name]:
            continue
        i_bbox = i_bboxes[model_id]
        v_bbox = v_bboxes[model_id]
        i_index_2_name = i_index_2_names[model_id]
        v_index_2_name = v_index_2_names[model_id]
        v_name_idx = res_idx[v_name][i_name][0]

        v_bbox_score = []
        for i in range(len(v_bbox[v_name_idx][:, 4])):
            v_frame_index = v_index_2_name[v_name_idx[i]].split('_')[-1][:-4]
            v_frame_index = int(v_frame_index)
            v_bbox_score.append(v_bbox[v_name_idx][i, 4] * get_score(v_frame_index))

        v_bbox_max_idx = np.array(v_bbox_score).argmax()
        v_final_idx = v_name_idx[v_bbox_max_idx]
        v_frame_index = v_index_2_name[v_final_idx].split('_')[-1][:-4]
        v_final_bbox = v_bbox[v_final_idx][:4].astype('int').tolist()

        i_name_idx = res_idx[v_name][i_name][1]
        i_bbox_max_idx = i_bbox[i_name_idx][:, 4].argmax()
        i_final_idx = i_name_idx[i_bbox_max_idx]
        i_img_name = i_index_2_name[i_final_idx].split('_')[1]
        i_item_id = i_index_2_name[i_final_idx].split('_')[2][:-4]
        i_final_bbox = i_bbox[i_final_idx][:4].astype('int').tolist()
        if v_name not in sub:
            sub[v_name] = {}
        sub[v_name]['item_id'] = i_item_id
        sub[v_name]['frame_index'] = int(v_frame_index)
        sub[v_name]['result'] = [{
                "img_name":i_img_name,
                "item_box":i_final_bbox,
                "frame_box":v_final_bbox,
        },]

        v_name_idx = res_idx[v_name][i_name][0]
        v_bbox_max_idx = v_bbox[v_name_idx][:, 4].argsort()[0]
        v_final_idx = v_name_idx[v_bbox_max_idx]
        v_frame_index = v_index_2_name[v_final_idx].split('_')[-1][:-4]
        v_final_bbox = v_bbox[v_final_idx][:4].astype('int').tolist()

        i_name_idx = res_idx[v_name][i_name][1]
        i_bbox_max_idx = i_bbox[i_name_idx][:, 4].argsort()[0]
        i_final_idx = i_name_idx[i_bbox_max_idx]
        i_img_name = i_index_2_name[i_final_idx].split('_')[1]
        i_item_id = i_index_2_name[i_final_idx].split('_')[2][:-4]
        i_final_bbox = i_bbox[i_final_idx][:4].astype('int').tolist()
        sub[v_name]['result'].append({
                "img_name":i_img_name,
                "item_box":i_final_bbox,
                "frame_box":v_final_bbox,
        })
        break

print(list(sub.items())[:30])
print('sub nums: ', len(sub))
print('V_TOP: {}, video num: {}'.format(v_top, len(res_idx)))
print('crop images nums >>>>>> image: {}, video: {}'.format(len(i_index_2_name), len(v_index_2_name)))

with open(args.output, 'w') as f:
    json.dump(sub, f)

if test_acc:
    acc_num = 0
    for v_name, item in sub.items():
        if v_name == item['item_id']:
            acc_num += 1
    print('acc : {:.6f}'.format(acc_num / len(sub)))