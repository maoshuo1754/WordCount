import json
import os
from tqdm import tqdm

dataset = [
    'train_dataset_part1'
]

images = []
annotations = []

ann_id = 1
for i, name in enumerate(dataset):
    path = os.path.join('/home/admin/workspace/myspace/train', name, 'annotations', 'train.json')
    # path = os.path.join('./', name, 'annotations', 'trainval.json')

    with open(path, 'r') as f:
        ann = json.load(f)
    
    images += ann['images']
    for item in ann['annotations']:
        item['id'] = ann_id
        ann_id += 1
    annotations += ann['annotations']
    print(name, len(ann['images']), len(ann['annotations']))


i_images = []
i_ann = []
i_ids = []
v_images = []
v_ann = []

for item in tqdm(images):
    if item['file_name'].startswith('i'):
        i_images.append(item)
        i_ids.append(item['id'])
    else:
        v_images.append(item)

i_ids = set(i_ids)
for item in tqdm(annotations):
    if item['image_id'] in i_ids:
        i_ann.append(item)
    else:
        v_ann.append(item)

ann['images'] = i_images
ann['annotations'] = i_ann
print('images: ', len(ann['images']), len(ann['annotations']))
with open('/home/admin/workspace/myspace/train/i_train.json', 'w') as f:
# with open('./i_train.json', 'w') as f:
    json.dump(ann, f)

ann['images'] = v_images
ann['annotations'] = v_ann
print('video: ', len(ann['images']), len(ann['annotations']))
# with open('./v_train.json', 'w') as f:
with open('/home/admin/workspace/myspace/train/v_train.json', 'w') as f:
    json.dump(ann, f)