import torch
import faiss
import numpy as np
import pdb

class DBA(object):
    """
    Every feature in the database is replaced with a weighted sum of the point ’s own value and those of its top k nearest neighbors (k-NN).
    c.f. https://www.robots.ox.ac.uk/~vgg/publications/2012/Arandjelovic12/arandjelovic12.pdf
    Hyper-Params:
        enhance_k (int): number of the nearest points to be calculated.
    """
    default_hyper_params = {
        "enhance_k": 10,
    }

    def __init__(self, top_k=10):
        """
        Args:
            hps (dict): default hyper parameters in a dict (keys, values).
        """
        self.top_k = top_k

    def knn(self, qf, gf, top_k):
        index = faiss.IndexFlatIP(gf.shape[1])
        index.add(gf)
        D, I = index.search(qf, top_k)
        return D, I

    def __call__(self, feature):
        print('start dba, feature.shape = {}, top k= {}'.format(feature.shape, self.top_k))
        _, sorted_idx = self.knn(feature, feature, self.top_k)
        sorted_idx = sorted_idx[:, 1:].reshape(-1)

        arg_fea = feature[sorted_idx].reshape((feature.shape[0], -1, feature.shape[1])).sum(axis=1)
        feature = feature + arg_fea
        faiss.normalize_L2(feature)

        return feature

if __name__ == "__main__":
    v_feat = np.random.random((10000, 2048)).astype('float32')
    i_feat = np.random.random((5000, 2048)).astype('float32')

    faiss.normalize_L2(i_feat)
    dba = DBA(10)
    i_feat = dba(i_feat)
