from mmdet.utils import Registry

DATASETS = Registry('dataset')
PIPELINES = Registry('pipeline')
